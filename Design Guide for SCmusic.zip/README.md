
  # Design Guide for SCmusic

  This is a code bundle for Design Guide for SCmusic. The original project is available at https://www.figma.com/design/7bI2h9ItUYNY19L6oRQQBK/Design-Guide-for-SCmusic.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  