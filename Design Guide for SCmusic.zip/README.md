
  # Design Guide for SCmusic

  This is a code bundle for Design Guide for SCmusic. The original project is available at https://www.figma.com/design/QSSZCi6sECSQ2yVif1h0RW/Design-Guide-for-SCmusic.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  