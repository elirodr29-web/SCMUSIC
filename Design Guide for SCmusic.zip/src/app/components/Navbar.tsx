import { useState } from "react";
import { Menu, X } from "lucide-react";

interface NavbarProps {
  activeSection: string;
  onNavigate: (section: string) => void;
}

const navLinks = [
  { id: "artistas", label: "ARTISTAS" },
  { id: "lancamentos", label: "LANÇAMENTOS" },
  { id: "shows", label: "SHOWS" },
  { id: "sobre", label: "SOBRE" },
];

export function Navbar({ activeSection, onNavigate }: NavbarProps) {
  const [menuOpen, setMenuOpen] = useState(false);

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 border-b border-border bg-background/90 backdrop-blur-sm">
      <div className="max-w-7xl mx-auto px-6 flex items-center justify-between h-16">
        <button
          onClick={() => onNavigate("hero")}
          className="text-primary tracking-widest cursor-pointer"
          style={{ fontFamily: "'Anton', sans-serif", fontSize: "1.5rem" }}
        >
          SC<span className="text-foreground">MUSIC</span>
        </button>

        {/* Desktop */}
        <div className="hidden md:flex items-center gap-8">
          {navLinks.map((link) => (
            <button
              key={link.id}
              onClick={() => onNavigate(link.id)}
              className={`text-xs tracking-widest transition-colors cursor-pointer ${
                activeSection === link.id
                  ? "text-primary"
                  : "text-muted-foreground hover:text-foreground"
              }`}
              style={{ fontFamily: "'DM Sans', sans-serif" }}
            >
              {link.label}
            </button>
          ))}
          <button
            onClick={() => onNavigate("shows")}
            className="bg-primary text-primary-foreground px-5 py-2 text-xs tracking-widest transition-opacity hover:opacity-80 cursor-pointer"
            style={{ fontFamily: "'DM Sans', sans-serif" }}
          >
            COMPRAR BILHETES
          </button>
        </div>

        {/* Mobile toggle */}
        <button
          className="md:hidden text-foreground"
          onClick={() => setMenuOpen(!menuOpen)}
        >
          {menuOpen ? <X size={22} /> : <Menu size={22} />}
        </button>
      </div>

      {/* Mobile menu */}
      {menuOpen && (
        <div className="md:hidden bg-card border-t border-border px-6 py-6 flex flex-col gap-5">
          {navLinks.map((link) => (
            <button
              key={link.id}
              onClick={() => { onNavigate(link.id); setMenuOpen(false); }}
              className="text-left text-sm tracking-widest text-muted-foreground hover:text-foreground transition-colors"
              style={{ fontFamily: "'DM Sans', sans-serif" }}
            >
              {link.label}
            </button>
          ))}
          <button
            onClick={() => { onNavigate("shows"); setMenuOpen(false); }}
            className="bg-primary text-primary-foreground px-5 py-3 text-xs tracking-widest text-center"
            style={{ fontFamily: "'DM Sans', sans-serif" }}
          >
            COMPRAR BILHETES
          </button>
        </div>
      )}
    </nav>
  );
}
