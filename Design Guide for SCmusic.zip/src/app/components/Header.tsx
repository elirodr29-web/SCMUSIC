import { useState } from "react";
import { Music2, Ticket, Search, Menu, X } from "lucide-react";

export function Header() {
  const [open, setOpen] = useState(false);

  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-[#080d18]/90 backdrop-blur-md border-b border-white/5">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center gap-2">
            <div className="w-9 h-9 rounded-full flex items-center justify-center" style={{ background: "linear-gradient(135deg, #FF6B00, #FFD700)" }}>
              <Music2 className="w-5 h-5 text-white" />
            </div>
            <span className="text-white font-bold text-xl tracking-tight">
              SC<span style={{ background: "linear-gradient(135deg, #FF6B00, #FFD700)", WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent" }}>music</span>
            </span>
          </div>

          <nav className="hidden md:flex items-center gap-8">
            {[["Início", "#inicio"], ["Artistas", "#artistas"], ["Eventos", "#eventos"], ["Sobre", "#sobre"]].map(([label, href]) => (
              <a key={label} href={href} className="text-sm text-[#8892a4] hover:text-white transition-colors font-medium">
                {label}
              </a>
            ))}
          </nav>

          <div className="hidden md:flex items-center gap-3">
            <button className="w-8 h-8 flex items-center justify-center text-[#8892a4] hover:text-white transition-colors">
              <Search className="w-4 h-4" />
            </button>
            <button
              className="flex items-center gap-2 px-4 py-2 rounded-full text-sm font-semibold text-white transition-all hover:scale-105 active:scale-95"
              style={{ background: "linear-gradient(135deg, #FF6B00, #FFD700)" }}
            >
              <Ticket className="w-4 h-4" />
              Bilhetes
            </button>
          </div>

          <button className="md:hidden text-white" onClick={() => setOpen(!open)}>
            {open ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {open && (
        <div className="md:hidden bg-[#0f1729] border-t border-white/5 px-4 py-4 space-y-1">
          {[["Início", "#inicio"], ["Artistas", "#artistas"], ["Eventos", "#eventos"], ["Sobre", "#sobre"]].map(([label, href]) => (
            <a key={label} href={href} className="block text-[#8892a4] hover:text-white py-2 text-sm font-medium" onClick={() => setOpen(false)}>
              {label}
            </a>
          ))}
          <div className="pt-2">
            <button className="w-full py-2 rounded-full text-sm font-semibold text-white" style={{ background: "linear-gradient(135deg, #FF6B00, #FFD700)" }}>
              Comprar Bilhetes
            </button>
          </div>
        </div>
      )}
    </header>
  );
}
