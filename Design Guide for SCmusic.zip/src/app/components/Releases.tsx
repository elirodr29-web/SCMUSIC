import { Play, ExternalLink } from "lucide-react";
import { useState } from "react";

const releases = [
  {
    id: 1,
    title: "Alma do Sul",
    artist: "NKOSI",
    type: "ÁLBUM",
    year: "2024",
    tracks: 12,
    image:
      "https://images.unsplash.com/photo-1580656449278-e8381933522c?w=600&h=600&fit=crop&auto=format",
  },
  {
    id: 2,
    title: "Noite Profunda",
    artist: "MAYA SOL",
    type: "EP",
    year: "2024",
    tracks: 6,
    image:
      "https://images.unsplash.com/photo-1619983081563-430f63602796?w=600&h=600&fit=crop&auto=format",
  },
  {
    id: 3,
    title: "Periférico",
    artist: "DJIBRIL",
    type: "ÁLBUM",
    year: "2023",
    tracks: 15,
    image:
      "https://images.unsplash.com/photo-1669801158950-f663cf15298c?w=600&h=600&fit=crop&auto=format",
  },
  {
    id: 4,
    title: "Vanguarda",
    artist: "LENA KOVA",
    type: "SINGLE",
    year: "2024",
    tracks: 1,
    image:
      "https://images.unsplash.com/photo-1672073314527-cd2d83182992?w=600&h=600&fit=crop&auto=format",
  },
  {
    id: 5,
    title: "Move Your Body",
    artist: "OSAS",
    type: "EP",
    year: "2024",
    tracks: 5,
    image:
      "https://images.unsplash.com/photo-1580656449278-e8381933522c?w=600&h=600&fit=crop&auto=format&sat=-100",
  },
];

export function Releases() {
  const [playing, setPlaying] = useState<number | null>(null);

  return (
    <section id="lancamentos" className="py-24 bg-card">
      <div className="max-w-7xl mx-auto px-6">
        {/* Header */}
        <div className="flex items-end justify-between mb-16 border-b border-border pb-8">
          <div>
            <p
              className="text-primary text-xs tracking-[0.4em] mb-3"
              style={{ fontFamily: "'DM Sans', sans-serif" }}
            >
              DISCOGRAFIA
            </p>
            <h2
              className="text-foreground leading-none"
              style={{ fontFamily: "'Anton', sans-serif", fontSize: "clamp(2.5rem, 6vw, 5rem)" }}
            >
              LANÇAMENTOS
            </h2>
          </div>
          <button
            className="text-muted-foreground text-xs tracking-widest hover:text-foreground transition-colors hidden md:flex items-center gap-2"
            style={{ fontFamily: "'DM Sans', sans-serif" }}
          >
            VER TUDO <ExternalLink size={12} />
          </button>
        </div>

        {/* Releases grid */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-px bg-border">
          {releases.map((release) => (
            <div
              key={release.id}
              className="bg-card group cursor-pointer"
              onClick={() => setPlaying(playing === release.id ? null : release.id)}
            >
              <div className="relative aspect-square overflow-hidden">
                <img
                  src={release.image}
                  alt={release.title}
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-background/0 group-hover:bg-background/50 transition-all duration-300 flex items-center justify-center">
                  <div className="opacity-0 group-hover:opacity-100 transition-opacity duration-300 bg-primary text-primary-foreground rounded-full p-4">
                    <Play size={20} fill="currentColor" />
                  </div>
                </div>
                {playing === release.id && (
                  <div className="absolute bottom-3 left-3">
                    <div className="flex gap-0.5 items-end h-4">
                      {[1, 2, 3, 4].map((b) => (
                        <div
                          key={b}
                          className="w-1 bg-primary animate-pulse"
                          style={{
                            height: `${Math.random() * 100}%`,
                            animationDelay: `${b * 0.1}s`,
                          }}
                        />
                      ))}
                    </div>
                  </div>
                )}
              </div>
              <div className="p-4">
                <div className="flex items-center justify-between mb-2">
                  <span
                    className="text-primary text-xs tracking-widest"
                    style={{ fontFamily: "'DM Sans', sans-serif", fontSize: "0.6rem" }}
                  >
                    {release.type}
                  </span>
                  <span
                    className="text-muted-foreground text-xs"
                    style={{ fontFamily: "'DM Sans', sans-serif", fontSize: "0.6rem" }}
                  >
                    {release.year}
                  </span>
                </div>
                <h3
                  className="text-foreground leading-tight mb-1"
                  style={{ fontFamily: "'Anton', sans-serif", fontSize: "1.1rem" }}
                >
                  {release.title}
                </h3>
                <p
                  className="text-muted-foreground"
                  style={{ fontFamily: "'DM Sans', sans-serif", fontSize: "0.75rem" }}
                >
                  {release.artist}
                </p>
                <p
                  className="text-muted-foreground mt-1"
                  style={{ fontFamily: "'DM Sans', sans-serif", fontSize: "0.65rem" }}
                >
                  {release.tracks} {release.tracks === 1 ? "faixa" : "faixas"}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
