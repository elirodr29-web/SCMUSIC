import { Play, Ticket, TrendingUp } from "lucide-react";

export function Hero() {
  return (
    <section id="inicio" className="relative min-h-screen flex items-center overflow-hidden">
      {/* Background image with dark overlay */}
      <div className="absolute inset-0">
        <img
          src="https://images.unsplash.com/photo-1506157786151-b8491531f063?w=1600&h=900&fit=crop&auto=format"
          alt="Concerto ao vivo"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0" style={{ background: "linear-gradient(135deg, rgba(8,13,24,0.95) 0%, rgba(0,33,71,0.85) 50%, rgba(8,13,24,0.75) 100%)" }} />
        {/* Orange glow accent */}
        <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-[600px] h-[300px] rounded-full blur-[120px] opacity-20" style={{ background: "linear-gradient(135deg, #FF6B00, #FFD700)" }} />
      </div>

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-24 pb-20 w-full">
        <div className="max-w-2xl">
          {/* Badge */}
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full mb-6 border border-white/10 bg-white/5 backdrop-blur-sm">
            <TrendingUp className="w-3.5 h-3.5 text-[#FFD700]" />
            <span className="text-[#FFD700] text-xs font-semibold tracking-widest uppercase">Cabo Verde · Música Independente</span>
          </div>

          <h1 className="text-white mb-6" style={{ fontSize: "clamp(2.5rem, 6vw, 4.5rem)", fontWeight: 800, lineHeight: 1.1, letterSpacing: "-0.02em" }}>
            A Alma de<br />
            <span style={{ background: "linear-gradient(135deg, #FF6B00, #FFD700)", WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent" }}>
              Cabo Verde
            </span><br />
            em Streaming
          </h1>

          <p className="text-[#8892a4] text-lg mb-10 leading-relaxed max-w-xl">
            Descobre os artistas independentes das ilhas, ouve as suas músicas e compra bilhetes para os melhores eventos ao vivo — tudo num só lugar.
          </p>

          <div className="flex flex-wrap gap-4">
            <button
              className="flex items-center gap-3 px-8 py-4 rounded-full text-white font-semibold text-base transition-all hover:scale-105 active:scale-95 shadow-lg"
              style={{ background: "linear-gradient(135deg, #FF6B00, #FFD700)", boxShadow: "0 8px 32px rgba(255, 107, 0, 0.4)" }}
            >
              <Play className="w-5 h-5 fill-white" />
              Ouvir Agora
            </button>
            <button
              className="flex items-center gap-3 px-8 py-4 rounded-full font-semibold text-base border border-white/20 text-white backdrop-blur-sm transition-all hover:bg-white/10"
            >
              <Ticket className="w-5 h-5" />
              Ver Eventos
            </button>
          </div>

          {/* Stats */}
          <div className="flex gap-8 mt-12 pt-8 border-t border-white/10">
            {[["12+", "Artistas"], ["3K+", "Ouvintes"], ["8", "Eventos"]].map(([num, label]) => (
              <div key={label}>
                <div className="text-white font-bold text-2xl">{num}</div>
                <div className="text-[#8892a4] text-sm">{label}</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
