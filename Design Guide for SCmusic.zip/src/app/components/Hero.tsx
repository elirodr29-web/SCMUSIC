import { Play, ArrowDown } from "lucide-react";

interface HeroProps {
  onNavigate: (section: string) => void;
}

export function Hero({ onNavigate }: HeroProps) {
  return (
    <section
      id="hero"
      className="relative min-h-screen flex flex-col justify-end overflow-hidden"
    >
      {/* Background image */}
      <div className="absolute inset-0">
        <img
          src="https://images.unsplash.com/photo-1549046701-6bd11cf71796?w=1800&h=1200&fit=crop&auto=format"
          alt="Artista no palco"
          className="w-full h-full object-cover object-center"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-background via-background/60 to-background/10" />
      </div>

      {/* Label tag top-right */}
      <div className="absolute top-24 right-6 md:right-12 flex flex-col items-end gap-1">
        <span
          className="text-primary text-xs tracking-[0.3em]"
          style={{ fontFamily: "'DM Sans', sans-serif" }}
        >
          LABEL INDEPENDENTE
        </span>
        <span
          className="text-muted-foreground text-xs tracking-widest"
          style={{ fontFamily: "'DM Sans', sans-serif" }}
        >
          EST. 2019 · ANGOLA
        </span>
      </div>

      {/* Content */}
      <div className="relative z-10 max-w-7xl mx-auto px-6 pb-20 w-full">
        <div className="max-w-3xl">
          <p
            className="text-primary text-xs tracking-[0.4em] mb-6"
            style={{ fontFamily: "'DM Sans', sans-serif" }}
          >
            EM DESTAQUE
          </p>
          <h1
            className="text-foreground leading-none mb-2"
            style={{
              fontFamily: "'Anton', sans-serif",
              fontSize: "clamp(3.5rem, 10vw, 8rem)",
            }}
          >
            NKOSI
          </h1>
          <h2
            className="text-muted-foreground mb-8"
            style={{
              fontFamily: "'Anton', sans-serif",
              fontSize: "clamp(1.5rem, 4vw, 3rem)",
            }}
          >
            "ALMA DO SUL"
          </h2>
          <p
            className="text-muted-foreground max-w-md mb-10 leading-relaxed"
            style={{ fontFamily: "'DM Sans', sans-serif", fontSize: "0.95rem" }}
          >
            O álbum debut que mistura Afrobeat, kizomba e produção eletrónica.
            Disponível agora em todas as plataformas.
          </p>

          <div className="flex flex-wrap gap-4">
            <button
              className="flex items-center gap-3 bg-primary text-primary-foreground px-8 py-4 text-sm tracking-widest hover:opacity-80 transition-opacity"
              style={{ fontFamily: "'DM Sans', sans-serif" }}
            >
              <Play size={15} fill="currentColor" />
              OUVIR AGORA
            </button>
            <button
              onClick={() => onNavigate("shows")}
              className="flex items-center gap-3 border border-border text-foreground px-8 py-4 text-sm tracking-widest hover:border-foreground transition-colors"
              style={{ fontFamily: "'DM Sans', sans-serif" }}
            >
              VER SHOWS
            </button>
          </div>
        </div>
      </div>

      {/* Scroll indicator */}
      <button
        onClick={() => onNavigate("artistas")}
        className="absolute bottom-8 left-1/2 -translate-x-1/2 text-muted-foreground hover:text-primary transition-colors animate-bounce"
      >
        <ArrowDown size={20} />
      </button>
    </section>
  );
}
