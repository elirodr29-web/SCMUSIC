import { useState } from "react";
import { MapPin, Calendar, Clock, Ticket, X, Check } from "lucide-react";

const shows = [
  {
    id: 1,
    artist: "NKOSI",
    eventName: "Alma do Sul · Tour 2025",
    venue: "Pavilhão Multiusos de Luanda",
    city: "Luanda, Angola",
    date: "2025-02-15",
    displayDate: "15 FEV 2025",
    time: "21:00",
    image:
      "https://images.unsplash.com/photo-1459749411175-04bf5292ceea?w=800&h=500&fit=crop&auto=format",
    tickets: [
      { type: "Geral", price: 3500, currency: "AOA", available: true },
      { type: "VIP", price: 8000, currency: "AOA", available: true },
      { type: "Camarote", price: 15000, currency: "AOA", available: false },
    ],
    soldOut: false,
  },
  {
    id: 2,
    artist: "MAYA SOL & DJIBRIL",
    eventName: "Noite Profunda · Collab Show",
    venue: "Anfiteatro do Lobito",
    city: "Lobito, Angola",
    date: "2025-03-08",
    displayDate: "08 MAR 2025",
    time: "20:30",
    image:
      "https://images.unsplash.com/photo-1470229722913-7c0e2dbbafd3?w=800&h=500&fit=crop&auto=format",
    tickets: [
      { type: "Geral", price: 2500, currency: "AOA", available: true },
      { type: "VIP", price: 6000, currency: "AOA", available: true },
    ],
    soldOut: false,
  },
  {
    id: 3,
    artist: "SCMUSIC ROSTER",
    eventName: "SCmusic Festival 2025",
    venue: "Cine Karl Marx",
    city: "Luanda, Angola",
    date: "2025-04-20",
    displayDate: "20 ABR 2025",
    time: "19:00",
    image:
      "https://images.unsplash.com/photo-1533174072545-7a4b6ad7a6c3?w=800&h=500&fit=crop&auto=format",
    tickets: [
      { type: "Dia único", price: 5000, currency: "AOA", available: true },
      { type: "Passe 2 dias", price: 8500, currency: "AOA", available: true },
      { type: "VIP All-Access", price: 20000, currency: "AOA", available: false },
    ],
    soldOut: false,
  },
  {
    id: 4,
    artist: "OSAS",
    eventName: "Move Your Body · Release Party",
    venue: "Club Tacos",
    city: "Huambo, Angola",
    date: "2025-01-30",
    displayDate: "30 JAN 2025",
    time: "22:00",
    image:
      "https://images.unsplash.com/photo-1429962714451-bb934ecdc4ec?w=800&h=500&fit=crop&auto=format",
    tickets: [
      { type: "Entrada", price: 1500, currency: "AOA", available: false },
    ],
    soldOut: true,
  },
];

function formatPrice(price: number) {
  return new Intl.NumberFormat("pt-AO").format(price);
}

interface ModalProps {
  show: typeof shows[0];
  onClose: () => void;
}

function TicketModal({ show, onClose }: ModalProps) {
  const [selected, setSelected] = useState<number | null>(null);
  const [quantity, setQuantity] = useState(1);
  const [purchased, setPurchased] = useState(false);

  const selectedTicket = selected !== null ? show.tickets[selected] : null;
  const total = selectedTicket ? selectedTicket.price * quantity : 0;

  function handleBuy() {
    if (!selectedTicket) return;
    setPurchased(true);
    setTimeout(() => {
      onClose();
      setPurchased(false);
    }, 2500);
  }

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4"
      onClick={onClose}
    >
      <div className="absolute inset-0 bg-background/80 backdrop-blur-sm" />
      <div
        className="relative bg-card border border-border w-full max-w-lg overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header image */}
        <div className="relative h-48 overflow-hidden">
          <img
            src={show.image}
            alt={show.eventName}
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-card to-transparent" />
          <button
            onClick={onClose}
            className="absolute top-4 right-4 text-foreground bg-background/60 p-1.5 hover:bg-background/90 transition-colors"
          >
            <X size={16} />
          </button>
          <div className="absolute bottom-4 left-6">
            <p
              className="text-primary text-xs tracking-widest"
              style={{ fontFamily: "'DM Sans', sans-serif" }}
            >
              {show.artist}
            </p>
            <h3
              className="text-foreground"
              style={{ fontFamily: "'Anton', sans-serif", fontSize: "1.6rem" }}
            >
              {show.eventName}
            </h3>
          </div>
        </div>

        <div className="p-6">
          {/* Event info */}
          <div className="flex flex-wrap gap-4 mb-6 pb-6 border-b border-border">
            <div className="flex items-center gap-2 text-muted-foreground text-sm">
              <Calendar size={14} className="text-primary" />
              <span style={{ fontFamily: "'DM Sans', sans-serif" }}>{show.displayDate}</span>
            </div>
            <div className="flex items-center gap-2 text-muted-foreground text-sm">
              <Clock size={14} className="text-primary" />
              <span style={{ fontFamily: "'DM Sans', sans-serif" }}>{show.time}</span>
            </div>
            <div className="flex items-center gap-2 text-muted-foreground text-sm">
              <MapPin size={14} className="text-primary" />
              <span style={{ fontFamily: "'DM Sans', sans-serif" }}>{show.city}</span>
            </div>
          </div>

          {purchased ? (
            <div className="flex flex-col items-center py-8 gap-4">
              <div className="bg-primary text-primary-foreground rounded-full p-4">
                <Check size={32} />
              </div>
              <p
                className="text-foreground text-center"
                style={{ fontFamily: "'Anton', sans-serif", fontSize: "1.4rem" }}
              >
                BILHETE CONFIRMADO!
              </p>
              <p
                className="text-muted-foreground text-sm text-center"
                style={{ fontFamily: "'DM Sans', sans-serif" }}
              >
                Receberá uma confirmação por email.
              </p>
            </div>
          ) : (
            <>
              {/* Ticket types */}
              <p
                className="text-xs tracking-widest text-muted-foreground mb-4"
                style={{ fontFamily: "'DM Sans', sans-serif" }}
              >
                ESCOLHA O BILHETE
              </p>
              <div className="flex flex-col gap-2 mb-6">
                {show.tickets.map((ticket, i) => (
                  <button
                    key={i}
                    disabled={!ticket.available}
                    onClick={() => setSelected(i)}
                    className={`flex items-center justify-between p-4 border transition-all text-left ${
                      !ticket.available
                        ? "border-border opacity-40 cursor-not-allowed"
                        : selected === i
                        ? "border-primary bg-primary/10"
                        : "border-border hover:border-foreground/30"
                    }`}
                  >
                    <div>
                      <p
                        className="text-foreground text-sm"
                        style={{ fontFamily: "'DM Sans', sans-serif" }}
                      >
                        {ticket.type}
                        {!ticket.available && (
                          <span className="ml-2 text-xs text-muted-foreground">(Esgotado)</span>
                        )}
                      </p>
                    </div>
                    <p
                      className="text-foreground"
                      style={{ fontFamily: "'Anton', sans-serif" }}
                    >
                      {formatPrice(ticket.price)} {ticket.currency}
                    </p>
                  </button>
                ))}
              </div>

              {/* Quantity */}
              {selected !== null && (
                <div className="flex items-center justify-between mb-6">
                  <p
                    className="text-xs tracking-widest text-muted-foreground"
                    style={{ fontFamily: "'DM Sans', sans-serif" }}
                  >
                    QUANTIDADE
                  </p>
                  <div className="flex items-center gap-4 border border-border">
                    <button
                      className="px-4 py-2 text-foreground hover:bg-muted transition-colors"
                      onClick={() => setQuantity(Math.max(1, quantity - 1))}
                    >
                      −
                    </button>
                    <span
                      className="text-foreground w-8 text-center"
                      style={{ fontFamily: "'Anton', sans-serif" }}
                    >
                      {quantity}
                    </span>
                    <button
                      className="px-4 py-2 text-foreground hover:bg-muted transition-colors"
                      onClick={() => setQuantity(Math.min(10, quantity + 1))}
                    >
                      +
                    </button>
                  </div>
                </div>
              )}

              {/* Total & CTA */}
              <div className="flex items-center justify-between pt-4 border-t border-border">
                <div>
                  {selected !== null && (
                    <>
                      <p
                        className="text-xs tracking-widest text-muted-foreground"
                        style={{ fontFamily: "'DM Sans', sans-serif" }}
                      >
                        TOTAL
                      </p>
                      <p
                        className="text-foreground"
                        style={{ fontFamily: "'Anton', sans-serif", fontSize: "1.4rem" }}
                      >
                        {formatPrice(total)} AOA
                      </p>
                    </>
                  )}
                </div>
                <button
                  disabled={selected === null}
                  onClick={handleBuy}
                  className={`flex items-center gap-2 px-8 py-4 text-sm tracking-widest transition-all ${
                    selected !== null
                      ? "bg-primary text-primary-foreground hover:opacity-80"
                      : "bg-muted text-muted-foreground cursor-not-allowed"
                  }`}
                  style={{ fontFamily: "'DM Sans', sans-serif" }}
                >
                  <Ticket size={14} />
                  COMPRAR
                </button>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
}

export function Shows() {
  const [selectedShow, setSelectedShow] = useState<typeof shows[0] | null>(null);

  return (
    <section id="shows" className="py-24 px-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex items-end justify-between mb-16 border-b border-border pb-8">
        <div>
          <p
            className="text-primary text-xs tracking-[0.4em] mb-3"
            style={{ fontFamily: "'DM Sans', sans-serif" }}
          >
            AO VIVO
          </p>
          <h2
            className="text-foreground leading-none"
            style={{ fontFamily: "'Anton', sans-serif", fontSize: "clamp(2.5rem, 6vw, 5rem)" }}
          >
            PRÓXIMOS SHOWS
          </h2>
        </div>
        <span
          className="text-muted-foreground text-sm tracking-widest hidden md:block"
          style={{ fontFamily: "'DM Sans', sans-serif" }}
        >
          {shows.filter((s) => !s.soldOut).length} DISPONÍVEIS
        </span>
      </div>

      {/* Shows list */}
      <div className="flex flex-col gap-px bg-border">
        {shows.map((show) => (
          <div
            key={show.id}
            className="bg-background grid grid-cols-1 md:grid-cols-[1fr_auto] items-center group"
          >
            {/* Left: image + info */}
            <div className="flex gap-0 overflow-hidden">
              <div className="relative w-40 h-28 md:w-56 md:h-36 flex-shrink-0 overflow-hidden">
                <img
                  src={show.image}
                  alt={show.eventName}
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                />
                {show.soldOut && (
                  <div className="absolute inset-0 bg-background/70 flex items-center justify-center">
                    <span
                      className="text-muted-foreground text-xs tracking-widest"
                      style={{ fontFamily: "'DM Sans', sans-serif" }}
                    >
                      ESGOTADO
                    </span>
                  </div>
                )}
              </div>
              <div className="p-6 flex flex-col justify-center">
                <p
                  className="text-primary text-xs tracking-widest mb-1"
                  style={{ fontFamily: "'DM Sans', sans-serif" }}
                >
                  {show.artist}
                </p>
                <h3
                  className="text-foreground mb-3 leading-tight"
                  style={{ fontFamily: "'Anton', sans-serif", fontSize: "1.4rem" }}
                >
                  {show.eventName}
                </h3>
                <div className="flex flex-wrap gap-4">
                  <div className="flex items-center gap-1.5 text-muted-foreground text-xs">
                    <Calendar size={11} />
                    <span style={{ fontFamily: "'DM Sans', sans-serif" }}>
                      {show.displayDate} · {show.time}
                    </span>
                  </div>
                  <div className="flex items-center gap-1.5 text-muted-foreground text-xs">
                    <MapPin size={11} />
                    <span style={{ fontFamily: "'DM Sans', sans-serif" }}>{show.venue}</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Right: price + CTA */}
            <div className="px-6 pb-6 md:pb-0 md:px-8 flex flex-col items-start md:items-end gap-2">
              {!show.soldOut && (
                <p
                  className="text-muted-foreground text-xs tracking-widest"
                  style={{ fontFamily: "'DM Sans', sans-serif" }}
                >
                  A partir de {formatPrice(show.tickets[0].price)} AOA
                </p>
              )}
              <button
                disabled={show.soldOut}
                onClick={() => !show.soldOut && setSelectedShow(show)}
                className={`flex items-center gap-2 px-6 py-3 text-xs tracking-widest transition-all ${
                  show.soldOut
                    ? "border border-border text-muted-foreground cursor-not-allowed"
                    : "bg-primary text-primary-foreground hover:opacity-80 cursor-pointer"
                }`}
                style={{ fontFamily: "'DM Sans', sans-serif" }}
              >
                <Ticket size={12} />
                {show.soldOut ? "ESGOTADO" : "COMPRAR BILHETES"}
              </button>
            </div>
          </div>
        ))}
      </div>

      {selectedShow && (
        <TicketModal show={selectedShow} onClose={() => setSelectedShow(null)} />
      )}
    </section>
  );
}
