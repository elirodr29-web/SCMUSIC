import { useState } from "react";
import { ExternalLink } from "lucide-react";

const artists = [
  {
    id: 1,
    name: "NKOSI",
    genre: "Afrobeat / Electrónico",
    releases: 3,
    image:
      "https://images.unsplash.com/photo-1549046701-6bd11cf71796?w=600&h=800&fit=crop&auto=format",
    bio: "Produtor e cantor de Luanda. Pioneiro da fusão entre kizomba e produção eletrónica contemporânea.",
    featured: true,
  },
  {
    id: 2,
    name: "MAYA SOL",
    genre: "R&B / Soul",
    releases: 5,
    image:
      "https://images.unsplash.com/photo-1552535867-bcffd9632b00?w=600&h=800&fit=crop&auto=format",
    bio: "Vocalista e compositora. As suas letras exploram identidade, amor e a diáspora africana.",
    featured: false,
  },
  {
    id: 3,
    name: "DJIBRIL",
    genre: "Hip-Hop / Trap",
    releases: 7,
    image:
      "https://images.unsplash.com/photo-1513180950021-b9ff91bb5e5b?w=600&h=800&fit=crop&auto=format",
    bio: "MC e beatmaker. As suas rimas cortantes falam da vida nas periferias de Maputo.",
    featured: false,
  },
  {
    id: 4,
    name: "LENA KOVA",
    genre: "Pop Alternativo",
    releases: 2,
    image:
      "https://images.unsplash.com/photo-1704253797699-f983e3cd70ff?w=600&h=800&fit=crop&auto=format",
    bio: "Artista multidisciplinar que combina arte visual com música pop de vanguarda.",
    featured: false,
  },
  {
    id: 5,
    name: "OSAS",
    genre: "Afropop / Dance",
    releases: 4,
    image:
      "https://images.unsplash.com/photo-1763889784402-5e8744af31b2?w=600&h=800&fit=crop&auto=format",
    bio: "Dançarino e artista de palco. Os seus shows são experiências totais de movimento e som.",
    featured: false,
  },
];

export function Artists() {
  const [hovered, setHovered] = useState<number | null>(null);

  return (
    <section id="artistas" className="py-24 px-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex items-end justify-between mb-16 border-b border-border pb-8">
        <div>
          <p
            className="text-primary text-xs tracking-[0.4em] mb-3"
            style={{ fontFamily: "'DM Sans', sans-serif" }}
          >
            ROSTER
          </p>
          <h2
            className="text-foreground leading-none"
            style={{ fontFamily: "'Anton', sans-serif", fontSize: "clamp(2.5rem, 6vw, 5rem)" }}
          >
            ARTISTAS
          </h2>
        </div>
        <span
          className="text-muted-foreground text-sm tracking-widest hidden md:block"
          style={{ fontFamily: "'DM Sans', sans-serif" }}
        >
          {artists.length} ARTISTAS
        </span>
      </div>

      {/* Featured artist */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-px bg-border mb-px">
        {/* Big feature */}
        <div
          className="relative bg-background overflow-hidden cursor-pointer group"
          style={{ minHeight: "500px" }}
          onMouseEnter={() => setHovered(1)}
          onMouseLeave={() => setHovered(null)}
        >
          <img
            src={artists[0].image}
            alt={artists[0].name}
            className="w-full h-full object-cover absolute inset-0 transition-transform duration-700 group-hover:scale-105"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-background via-background/30 to-transparent" />
          <div className="absolute top-5 left-5">
            <span
              className="bg-primary text-primary-foreground text-xs px-3 py-1 tracking-widest"
              style={{ fontFamily: "'DM Sans', sans-serif" }}
            >
              DESTAQUE
            </span>
          </div>
          <div className="absolute bottom-0 left-0 right-0 p-8">
            <p
              className="text-muted-foreground text-xs tracking-widest mb-2"
              style={{ fontFamily: "'DM Sans', sans-serif" }}
            >
              {artists[0].genre}
            </p>
            <h3
              className="text-foreground mb-3 leading-none"
              style={{ fontFamily: "'Anton', sans-serif", fontSize: "3rem" }}
            >
              {artists[0].name}
            </h3>
            <p
              className="text-muted-foreground text-sm leading-relaxed mb-4 max-w-sm"
              style={{ fontFamily: "'DM Sans', sans-serif" }}
            >
              {artists[0].bio}
            </p>
            <div className="flex items-center gap-2 text-primary text-xs tracking-widest">
              <ExternalLink size={12} />
              <span style={{ fontFamily: "'DM Sans', sans-serif" }}>VER PERFIL</span>
            </div>
          </div>
        </div>

        {/* Grid of others */}
        <div className="grid grid-cols-2 gap-px bg-border">
          {artists.slice(1).map((artist) => (
            <div
              key={artist.id}
              className="relative bg-background overflow-hidden cursor-pointer group"
              style={{ minHeight: "240px" }}
              onMouseEnter={() => setHovered(artist.id)}
              onMouseLeave={() => setHovered(null)}
            >
              <img
                src={artist.image}
                alt={artist.name}
                className="w-full h-full object-cover absolute inset-0 transition-transform duration-700 group-hover:scale-110"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-background/90 via-background/20 to-transparent" />
              <div className="absolute bottom-0 left-0 right-0 p-5">
                <p
                  className="text-muted-foreground text-xs tracking-widest mb-1"
                  style={{ fontFamily: "'DM Sans', sans-serif", fontSize: "0.6rem" }}
                >
                  {artist.genre}
                </p>
                <h3
                  className="text-foreground leading-none"
                  style={{ fontFamily: "'Anton', sans-serif", fontSize: "1.4rem" }}
                >
                  {artist.name}
                </h3>
                <p
                  className="text-muted-foreground text-xs mt-1 opacity-0 group-hover:opacity-100 transition-opacity duration-300"
                  style={{ fontFamily: "'DM Sans', sans-serif" }}
                >
                  {artist.releases} lançamentos
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
