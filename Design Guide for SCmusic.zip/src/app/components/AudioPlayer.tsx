import { useState, useEffect, useRef } from "react";
import { Play, Pause, SkipBack, SkipForward, Volume2, Heart, Maximize2, X } from "lucide-react";

interface AudioPlayerProps {
  artistName: string;
  trackName: string;
  artistImage?: string;
  onClose: () => void;
}

export function AudioPlayer({ artistName, trackName, artistImage, onClose }: AudioPlayerProps) {
  const [isPlaying, setIsPlaying] = useState(true);
  const [progress, setProgress] = useState(0);
  const [liked, setLiked] = useState(false);
  const [volume, setVolume] = useState(80);
  const intervalRef = useRef<number | null>(null);

  useEffect(() => {
    if (isPlaying) {
      intervalRef.current = window.setInterval(() => {
        setProgress((p) => (p >= 100 ? 0 : p + 0.3));
      }, 100);
    } else {
      if (intervalRef.current) clearInterval(intervalRef.current);
    }
    return () => { if (intervalRef.current) clearInterval(intervalRef.current); };
  }, [isPlaying]);

  const formatTime = (pct: number) => {
    const total = 242;
    const sec = Math.floor((pct / 100) * total);
    return `${Math.floor(sec / 60)}:${String(sec % 60).padStart(2, "0")}`;
  };

  return (
    <div className="fixed bottom-0 left-0 right-0 z-50 border-t border-white/10 backdrop-blur-xl" style={{ background: "rgba(8,13,24,0.95)" }}>
      {/* Progress bar — full width */}
      <div
        className="h-1 cursor-pointer w-full"
        style={{ background: "rgba(255,255,255,0.1)" }}
        onClick={(e) => {
          const rect = e.currentTarget.getBoundingClientRect();
          setProgress(((e.clientX - rect.left) / rect.width) * 100);
        }}
      >
        <div
          className="h-full rounded-full transition-none relative"
          style={{ width: `${progress}%`, background: "linear-gradient(90deg, #FF6B00, #FFD700)" }}
        >
          <div className="absolute right-0 top-1/2 -translate-y-1/2 w-3 h-3 rounded-full bg-white shadow-md -mr-1.5 opacity-0 hover:opacity-100 transition-opacity" />
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 h-20 flex items-center gap-4">
        {/* Track info */}
        <div className="flex items-center gap-3 w-64 min-w-0">
          <div className="w-12 h-12 rounded-lg overflow-hidden flex-shrink-0 bg-[#162040]">
            {artistImage ? (
              <img src={artistImage} alt={artistName} className="w-full h-full object-cover" />
            ) : (
              <div className="w-full h-full flex items-center justify-center" style={{ background: "linear-gradient(135deg, #FF6B00, #FFD700)" }}>
                <span className="text-white font-bold text-lg">{artistName[0]}</span>
              </div>
            )}
          </div>
          <div className="min-w-0">
            <div className="text-white text-sm font-semibold truncate">{trackName}</div>
            <div className="text-[#8892a4] text-xs truncate">{artistName}</div>
          </div>
          <button onClick={() => setLiked(!liked)} className="ml-1 flex-shrink-0">
            <Heart className={`w-4 h-4 transition-colors ${liked ? "fill-[#FF6B00] text-[#FF6B00]" : "text-[#8892a4] hover:text-white"}`} />
          </button>
        </div>

        {/* Controls — center */}
        <div className="flex-1 flex flex-col items-center gap-1">
          <div className="flex items-center gap-4">
            <button className="text-[#8892a4] hover:text-white transition-colors">
              <SkipBack className="w-5 h-5" />
            </button>
            <button
              onClick={() => setIsPlaying(!isPlaying)}
              className="w-10 h-10 rounded-full flex items-center justify-center transition-all hover:scale-110"
              style={{ background: "linear-gradient(135deg, #FF6B00, #FFD700)" }}
            >
              {isPlaying ? <Pause className="w-5 h-5 text-white fill-white" /> : <Play className="w-5 h-5 text-white fill-white ml-0.5" />}
            </button>
            <button className="text-[#8892a4] hover:text-white transition-colors">
              <SkipForward className="w-5 h-5" />
            </button>
          </div>
          <div className="flex items-center gap-2 text-xs text-[#8892a4]">
            <span>{formatTime(progress)}</span>
            <span className="text-[#333]">—</span>
            <span>4:02</span>
          </div>
        </div>

        {/* Volume + close */}
        <div className="hidden md:flex items-center gap-3 w-48 justify-end">
          <Volume2 className="w-4 h-4 text-[#8892a4]" />
          <input
            type="range"
            min={0}
            max={100}
            value={volume}
            onChange={(e) => setVolume(+e.target.value)}
            className="w-20 h-1 rounded-full appearance-none cursor-pointer"
            style={{ accentColor: "#FF6B00" }}
          />
          <button className="text-[#8892a4] hover:text-white transition-colors">
            <Maximize2 className="w-4 h-4" />
          </button>
          <button onClick={onClose} className="text-[#8892a4] hover:text-white transition-colors ml-1">
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Mobile close */}
        <button onClick={onClose} className="md:hidden text-[#8892a4] hover:text-white transition-colors">
          <X className="w-5 h-5" />
        </button>
      </div>
    </div>
  );
}
