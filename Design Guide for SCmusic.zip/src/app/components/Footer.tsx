import { Music2, Mail, Instagram, Twitter, Youtube } from "lucide-react";

export function Footer() {
  return (
    <footer className="bg-[#0a0f1e] border-t border-white/5 pt-16 pb-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid md:grid-cols-4 gap-10 mb-12">
          {/* Brand */}
          <div className="md:col-span-2">
            <div className="flex items-center gap-2 mb-4">
              <div className="w-9 h-9 rounded-full flex items-center justify-center" style={{ background: "linear-gradient(135deg, #FF6B00, #FFD700)" }}>
                <Music2 className="w-5 h-5 text-white" />
              </div>
              <span className="text-white font-bold text-xl tracking-tight">
                SC<span style={{ background: "linear-gradient(135deg, #FF6B00, #FFD700)", WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent" }}>music</span>
              </span>
            </div>
            <p className="text-[#8892a4] text-sm leading-relaxed max-w-xs">
              A plataforma de música independente de Cabo Verde. Descobre artistas, ouve músicas e compra bilhetes para os melhores eventos das ilhas.
            </p>
            <div className="flex gap-3 mt-5">
              {[Instagram, Twitter, Youtube].map((Icon, i) => (
                <button key={i} className="w-9 h-9 rounded-full bg-white/5 hover:bg-white/10 flex items-center justify-center transition-colors border border-white/5">
                  <Icon className="w-4 h-4 text-[#8892a4]" />
                </button>
              ))}
              <button className="w-9 h-9 rounded-full bg-white/5 hover:bg-white/10 flex items-center justify-center transition-colors border border-white/5">
                <Mail className="w-4 h-4 text-[#8892a4]" />
              </button>
            </div>
          </div>

          {/* Links */}
          <div>
            <h4 className="text-white font-semibold mb-4 text-sm">Plataforma</h4>
            <ul className="space-y-2.5">
              {["Artistas", "Eventos", "Bilhetes", "Charts"].map((item) => (
                <li key={item}>
                  <a href="#" className="text-[#8892a4] hover:text-white text-sm transition-colors">{item}</a>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="text-white font-semibold mb-4 text-sm">Suporte</h4>
            <ul className="space-y-2.5">
              {["Sobre Nós", "Contacto", "Termos", "Privacidade"].map((item) => (
                <li key={item}>
                  <a href="#" className="text-[#8892a4] hover:text-white text-sm transition-colors">{item}</a>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Map of Cape Verde islands — simplified SVG */}
        <div className="mb-10 p-6 bg-[#0f1729] rounded-2xl border border-white/5">
          <p className="text-[#8892a4] text-xs uppercase tracking-widest mb-4 font-semibold">Ilhas de Cabo Verde</p>
          <div className="relative h-32 overflow-hidden">
            <svg viewBox="0 0 400 130" className="w-full h-full" fill="none">
              {/* Stylized island dots with labels */}
              {[
                { cx: 95, cy: 40, r: 18, label: "Santo Antão", sub: "NW" },
                { cx: 145, cy: 35, r: 12, label: "São Vicente", sub: "Mindelo" },
                { cx: 175, cy: 30, r: 6, label: "Santa Luzia", sub: "" },
                { cx: 200, cy: 38, r: 8, label: "São Nicolau", sub: "" },
                { cx: 270, cy: 28, r: 10, label: "Sal", sub: "Santa Maria" },
                { cx: 305, cy: 40, r: 9, label: "Boa Vista", sub: "" },
                { cx: 120, cy: 90, r: 7, label: "São Vicente", sub: "" },
                { cx: 165, cy: 95, r: 14, label: "Santiago", sub: "Praia" },
                { cx: 200, cy: 88, r: 6, label: "Maio", sub: "" },
                { cx: 240, cy: 85, r: 11, label: "Fogo", sub: "" },
                { cx: 270, cy: 100, r: 6, label: "Brava", sub: "" },
              ].map((island, i) => (
                <g key={i}>
                  <circle
                    cx={island.cx}
                    cy={island.cy}
                    r={island.r}
                    fill="url(#islandGrad)"
                    opacity={0.7}
                    className="hover:opacity-100 transition-opacity cursor-pointer"
                  />
                  {island.r >= 10 && (
                    <text x={island.cx} y={island.cy + island.r + 10} textAnchor="middle" fill="#8892a4" fontSize="7" fontFamily="sans-serif">
                      {island.sub || island.label}
                    </text>
                  )}
                </g>
              ))}
              <defs>
                <linearGradient id="islandGrad" x1="0" y1="0" x2="1" y2="1">
                  <stop offset="0%" stopColor="#FF6B00" />
                  <stop offset="100%" stopColor="#FFD700" />
                </linearGradient>
              </defs>
            </svg>
          </div>
        </div>

        <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pt-6 border-t border-white/5">
          <p className="text-[#8892a4] text-xs">© 2026 SCmusic · Cabo Verde · Todos os direitos reservados</p>
          <p className="text-[#8892a4] text-xs">Pagamentos: Vinti4 · VISA · Mastercard</p>
        </div>
      </div>
    </footer>
  );
}
