import { Instagram, Youtube, Twitter } from "lucide-react";

export function Footer() {
  return (
    <footer className="border-t border-border bg-background">
      <div className="max-w-7xl mx-auto px-6 py-16">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-16">
          {/* Brand */}
          <div className="md:col-span-2">
            <p
              className="text-foreground tracking-widest mb-4"
              style={{ fontFamily: "'Anton', sans-serif", fontSize: "2rem" }}
            >
              SC<span className="text-primary">MUSIC</span>
            </p>
            <p
              className="text-muted-foreground text-sm leading-relaxed max-w-xs"
              style={{ fontFamily: "'DM Sans', sans-serif" }}
            >
              Editora musical independente. Luanda, Angola. Amplificando vozes africanas desde 2019.
            </p>
            <div className="flex gap-4 mt-6">
              {[
                { icon: <Instagram size={18} />, label: "Instagram" },
                { icon: <Youtube size={18} />, label: "YouTube" },
                { icon: <Twitter size={18} />, label: "Twitter" },
              ].map((s) => (
                <button
                  key={s.label}
                  className="text-muted-foreground hover:text-primary transition-colors"
                  aria-label={s.label}
                >
                  {s.icon}
                </button>
              ))}
            </div>
          </div>

          {/* Links */}
          <div>
            <p
              className="text-xs tracking-widest text-muted-foreground mb-6"
              style={{ fontFamily: "'DM Sans', sans-serif" }}
            >
              NAVEGAÇÃO
            </p>
            {["Artistas", "Lançamentos", "Shows", "Sobre"].map((l) => (
              <p key={l} className="mb-3">
                <a
                  href="#"
                  className="text-foreground text-sm hover:text-primary transition-colors"
                  style={{ fontFamily: "'DM Sans', sans-serif" }}
                >
                  {l}
                </a>
              </p>
            ))}
          </div>

          {/* Contact */}
          <div>
            <p
              className="text-xs tracking-widest text-muted-foreground mb-6"
              style={{ fontFamily: "'DM Sans', sans-serif" }}
            >
              CONTACTO
            </p>
            <p
              className="text-sm text-foreground mb-2"
              style={{ fontFamily: "'DM Sans', sans-serif" }}
            >
              booking@scmusic.ao
            </p>
            <p
              className="text-sm text-foreground mb-2"
              style={{ fontFamily: "'DM Sans', sans-serif" }}
            >
              press@scmusic.ao
            </p>
            <p
              className="text-sm text-muted-foreground mt-4 leading-relaxed"
              style={{ fontFamily: "'DM Sans', sans-serif" }}
            >
              Rua Major Kanhangulo, 23<br />
              Luanda, Angola
            </p>
          </div>
        </div>

        {/* Bottom bar */}
        <div className="border-t border-border pt-8 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <p
            className="text-muted-foreground text-xs tracking-widest"
            style={{ fontFamily: "'DM Sans', sans-serif" }}
          >
            © 2025 SCMUSIC. TODOS OS DIREITOS RESERVADOS.
          </p>
          <div className="flex gap-6">
            {["Privacidade", "Termos", "Cookies"].map((l) => (
              <a
                key={l}
                href="#"
                className="text-muted-foreground text-xs tracking-widest hover:text-foreground transition-colors"
                style={{ fontFamily: "'DM Sans', sans-serif" }}
              >
                {l.toUpperCase()}
              </a>
            ))}
          </div>
        </div>
      </div>
    </footer>
  );
}
