import { useState } from "react";
import { Calendar, MapPin, Users, Ticket, ChevronRight } from "lucide-react";

export interface Event {
  id: string;
  title: string;
  date: string;
  location: string;
  artists: string;
  image: string;
  price: string;
  payment: string;
  available?: number;
}

export function EventCard({ event }: { event: Event }) {
  const [buying, setBuying] = useState(false);

  const handleBuy = () => {
    setBuying(true);
    setTimeout(() => setBuying(false), 2000);
  };

  const available = event.available ?? Math.floor(Math.random() * 80) + 10;
  const isSoldOut = available === 0;
  const isLow = available < 20;

  return (
    <div className="group flex gap-0 bg-[#0f1729] rounded-2xl overflow-hidden border border-white/5 hover:border-white/15 transition-all hover:shadow-xl hover:shadow-black/30">
      {/* Image */}
      <div className="relative w-40 sm:w-56 flex-shrink-0 overflow-hidden">
        <img
          src={event.image}
          alt={event.title}
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-transparent to-[#0f1729]/60" />
        {/* Date badge */}
        <div className="absolute top-3 left-3 bg-[#080d18]/80 backdrop-blur-sm rounded-xl px-2.5 py-1.5 text-center border border-white/10">
          <div className="text-[#FFD700] font-bold text-lg leading-none">{event.date.split(" ")[0]}</div>
          <div className="text-[#8892a4] text-xs uppercase tracking-wide">{event.date.split(" ")[2]}</div>
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 p-5 flex flex-col justify-between min-w-0">
        <div>
          <div className="flex items-start justify-between gap-3 mb-2">
            <h3 className="text-white font-bold text-base sm:text-lg leading-tight truncate">{event.title}</h3>
            <ChevronRight className="w-4 h-4 text-[#8892a4] flex-shrink-0 mt-1 group-hover:text-white group-hover:translate-x-0.5 transition-all" />
          </div>

          <div className="flex flex-wrap gap-x-4 gap-y-1.5 mb-3">
            <div className="flex items-center gap-1.5 text-sm text-[#8892a4]">
              <MapPin className="w-3.5 h-3.5 text-[#FF6B00]" />
              {event.location}
            </div>
            <div className="flex items-center gap-1.5 text-sm text-[#8892a4]">
              <Users className="w-3.5 h-3.5 text-[#FF6B00]" />
              {event.artists}
            </div>
            <div className="flex items-center gap-1.5 text-sm text-[#8892a4]">
              <Calendar className="w-3.5 h-3.5 text-[#FF6B00]" />
              {event.date}
            </div>
          </div>

          {/* Availability bar */}
          <div className="flex items-center gap-2 mb-1">
            <div className="flex-1 h-1 bg-white/10 rounded-full overflow-hidden">
              <div
                className="h-full rounded-full transition-all"
                style={{
                  width: `${(available / 100) * 100}%`,
                  background: isLow ? "linear-gradient(90deg, #FF6B00, #FFD700)" : "linear-gradient(90deg, #22c55e, #4ade80)"
                }}
              />
            </div>
            <span className={`text-xs font-medium ${isLow ? "text-[#FF6B00]" : "text-[#8892a4]"}`}>
              {isSoldOut ? "Esgotado" : isLow ? `Últimos ${available} bilhetes` : `${available} disponíveis`}
            </span>
          </div>
        </div>

        {/* Bottom row */}
        <div className="flex items-center justify-between gap-3 mt-3 pt-3 border-t border-white/5">
          <div>
            <div className="text-white font-bold text-xl">{event.price}</div>
            <div className="text-[#8892a4] text-xs">{event.payment}</div>
          </div>
          <button
            onClick={handleBuy}
            disabled={isSoldOut || buying}
            className="flex items-center gap-2 px-5 py-2.5 rounded-full text-sm font-bold text-white transition-all hover:scale-105 active:scale-95 disabled:opacity-60 disabled:cursor-not-allowed disabled:hover:scale-100"
            style={{ background: buying ? "linear-gradient(135deg, #22c55e, #4ade80)" : "linear-gradient(135deg, #FF6B00, #FFD700)" }}
          >
            <Ticket className="w-4 h-4" />
            {buying ? "Adicionado!" : isSoldOut ? "Esgotado" : "Comprar"}
          </button>
        </div>
      </div>
    </div>
  );
}
