import { Music, Globe, Users } from "lucide-react";

const stats = [
  { value: "5", label: "ARTISTAS" },
  { value: "21", label: "LANÇAMENTOS" },
  { value: "6", label: "ANOS" },
  { value: "12k+", label: "FÃS" },
];

export function About() {
  return (
    <section id="sobre" className="py-24 bg-card border-t border-border">
      <div className="max-w-7xl mx-auto px-6">
        {/* Header */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-16 mb-20">
          <div>
            <p
              className="text-primary text-xs tracking-[0.4em] mb-6"
              style={{ fontFamily: "'DM Sans', sans-serif" }}
            >
              SOBRE NÓS
            </p>
            <h2
              className="text-foreground leading-none mb-0"
              style={{ fontFamily: "'Anton', sans-serif", fontSize: "clamp(2.5rem, 6vw, 5rem)" }}
            >
              SOMOS O
            </h2>
            <h2
              className="text-primary leading-none"
              style={{ fontFamily: "'Anton', sans-serif", fontSize: "clamp(2.5rem, 6vw, 5rem)" }}
            >
              FUTURO DA
            </h2>
            <h2
              className="text-foreground leading-none"
              style={{ fontFamily: "'Anton', sans-serif", fontSize: "clamp(2.5rem, 6vw, 5rem)" }}
            >
              MÚSICA AFRICANA
            </h2>
          </div>
          <div className="flex flex-col justify-end">
            <p
              className="text-muted-foreground leading-relaxed mb-6"
              style={{ fontFamily: "'DM Sans', sans-serif", fontSize: "1rem" }}
            >
              A SCmusic é uma editora musical independente fundada em 2019, com sede em Luanda, Angola.
              Nascemos com a missão de amplificar vozes africanas autênticas para o mundo, apoiando
              artistas que fundem tradição e modernidade.
            </p>
            <p
              className="text-muted-foreground leading-relaxed"
              style={{ fontFamily: "'DM Sans', sans-serif", fontSize: "1rem" }}
            >
              O nosso catálogo abrange Afrobeat, kizomba, R&B, hip-hop e pop alternativo —
              géneros que definem a sonoridade do continente do século XXI.
            </p>
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-px bg-border mb-20">
          {stats.map((stat) => (
            <div key={stat.label} className="bg-card p-10 text-center">
              <p
                className="text-primary leading-none mb-2"
                style={{ fontFamily: "'Anton', sans-serif", fontSize: "3.5rem" }}
              >
                {stat.value}
              </p>
              <p
                className="text-muted-foreground text-xs tracking-widest"
                style={{ fontFamily: "'DM Sans', sans-serif" }}
              >
                {stat.label}
              </p>
            </div>
          ))}
        </div>

        {/* Values */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-px bg-border">
          {[
            {
              icon: <Music size={24} className="text-primary" />,
              title: "AUTENTICIDADE",
              body: "Acreditamos que a melhor música nasce da experiência vivida. Trabalhamos com artistas que têm algo genuíno a dizer.",
            },
            {
              icon: <Users size={24} className="text-primary" />,
              title: "COMUNIDADE",
              body: "Construímos pontes entre artistas, fãs e a indústria. Os nossos eventos são espaços de encontro e cultura.",
            },
            {
              icon: <Globe size={24} className="text-primary" />,
              title: "PROJEÇÃO GLOBAL",
              body: "Angola para o mundo. Levamos os nossos artistas a palcos internacionais mantendo as raízes no continente.",
            },
          ].map((val) => (
            <div key={val.title} className="bg-card p-10">
              <div className="mb-5">{val.icon}</div>
              <h3
                className="text-foreground mb-4"
                style={{ fontFamily: "'Anton', sans-serif", fontSize: "1.3rem" }}
              >
                {val.title}
              </h3>
              <p
                className="text-muted-foreground leading-relaxed text-sm"
                style={{ fontFamily: "'DM Sans', sans-serif" }}
              >
                {val.body}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
