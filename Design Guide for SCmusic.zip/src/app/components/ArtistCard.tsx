import { useState } from "react";
import { Play, Pause, Heart, MoreHorizontal, Music } from "lucide-react";

export interface Artist {
  id: string;
  name: string;
  image: string;
  type: "audio" | "ticket";
  trackName?: string;
  genre: string;
  description: string;
  followers?: string;
  tracks?: { title: string; duration: string; plays: string }[];
}

interface ArtistCardProps {
  artist: Artist;
  onPlayAudio: (id: string) => void;
  isPlaying: boolean;
}

export function ArtistCard({ artist, onPlayAudio, isPlaying }: ArtistCardProps) {
  const [liked, setLiked] = useState(false);
  const [hovered, setHovered] = useState(false);

  const tracks = artist.tracks ?? [
    { title: artist.trackName ?? "Faixa 1", duration: "3:42", plays: "24K" },
    { title: "Interlude", duration: "2:18", plays: "18K" },
    { title: "Outro", duration: "4:05", plays: "12K" },
  ];

  return (
    <div className="bg-[#0f1729] rounded-2xl overflow-hidden border border-white/5 hover:border-white/10 transition-all group">
      {/* Cover art */}
      <div
        className="relative aspect-square overflow-hidden cursor-pointer"
        onMouseEnter={() => setHovered(true)}
        onMouseLeave={() => setHovered(false)}
        onClick={() => onPlayAudio(artist.id)}
      >
        <img
          src={artist.image}
          alt={artist.name}
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-[#080d18] via-transparent to-transparent opacity-80" />

        {/* Genre badge */}
        <div className="absolute top-4 left-4 px-3 py-1 rounded-full text-xs font-bold tracking-widest" style={{ background: "linear-gradient(135deg, #FF6B00, #FFD700)", color: "#080d18" }}>
          {artist.genre}
        </div>

        {/* Play overlay */}
        <div className={`absolute inset-0 flex items-center justify-center transition-opacity duration-200 ${hovered || isPlaying ? "opacity-100" : "opacity-0"}`}>
          <button
            className="w-16 h-16 rounded-full flex items-center justify-center shadow-2xl transition-transform hover:scale-110 active:scale-95"
            style={{ background: "linear-gradient(135deg, #FF6B00, #FFD700)", boxShadow: "0 8px 32px rgba(255,107,0,0.5)" }}
          >
            {isPlaying ? <Pause className="w-7 h-7 text-white fill-white" /> : <Play className="w-7 h-7 text-white fill-white ml-1" />}
          </button>
        </div>

        {/* Playing indicator */}
        {isPlaying && (
          <div className="absolute bottom-4 left-4 flex items-center gap-1.5">
            {[0, 1, 2].map((i) => (
              <div
                key={i}
                className="w-1 rounded-full"
                style={{
                  background: "linear-gradient(135deg, #FF6B00, #FFD700)",
                  height: "16px",
                  animation: `bounce 0.8s ease-in-out ${i * 0.15}s infinite alternate`,
                }}
              />
            ))}
            <span className="text-xs text-[#FFD700] font-semibold ml-1">A tocar</span>
          </div>
        )}
      </div>

      {/* Info */}
      <div className="p-5">
        <div className="flex items-start justify-between mb-3">
          <div>
            <h3 className="text-white font-bold text-lg leading-tight">{artist.name}</h3>
            <p className="text-[#8892a4] text-sm mt-0.5">{artist.followers ?? "24.5K"} seguidores</p>
          </div>
          <div className="flex items-center gap-2">
            <button onClick={() => setLiked(!liked)} className="w-8 h-8 flex items-center justify-center rounded-full hover:bg-white/10 transition-colors">
              <Heart className={`w-4 h-4 transition-colors ${liked ? "fill-[#FF6B00] text-[#FF6B00]" : "text-[#8892a4]"}`} />
            </button>
            <button className="w-8 h-8 flex items-center justify-center rounded-full hover:bg-white/10 transition-colors">
              <MoreHorizontal className="w-4 h-4 text-[#8892a4]" />
            </button>
          </div>
        </div>

        <p className="text-[#8892a4] text-sm leading-relaxed mb-4 line-clamp-2">{artist.description}</p>

        {/* Track list */}
        <div className="space-y-1 border-t border-white/5 pt-4">
          {tracks.map((track, i) => (
            <div
              key={i}
              className="flex items-center gap-3 px-2 py-2 rounded-lg hover:bg-white/5 cursor-pointer group/track transition-colors"
              onClick={() => onPlayAudio(artist.id)}
            >
              <span className="w-5 text-center text-xs text-[#8892a4] group-hover/track:hidden">{i + 1}</span>
              <Music className="w-3 h-3 text-[#FF6B00] hidden group-hover/track:block flex-shrink-0" />
              <span className="flex-1 text-sm text-[#f0f2f8] truncate">{track.title}</span>
              <span className="text-xs text-[#8892a4]">{track.plays}</span>
              <span className="text-xs text-[#8892a4] w-8 text-right">{track.duration}</span>
            </div>
          ))}
        </div>
      </div>

      <style>{`
        @keyframes bounce {
          from { transform: scaleY(0.4); }
          to { transform: scaleY(1); }
        }
      `}</style>
    </div>
  );
}
