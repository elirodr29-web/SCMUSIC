import { useState } from "react";
import { Ticket, Music2, TrendingUp, Headphones, Play } from "lucide-react";
import { Header } from "./components/Header";
import { Hero } from "./components/Hero";
import { ArtistCard, Artist } from "./components/ArtistCard";
import { EventCard, Event } from "./components/EventCard";
import { AudioPlayer } from "./components/AudioPlayer";
import { Footer } from "./components/Footer";

const FEATURED_TRACKS = [
  { title: "Sodade de Nós Terra", artist: "Carlos Rosa", plays: "124K", duration: "4:02" },
  { title: "Rua Di Mudança", artist: "MR.462", plays: "98K", duration: "3:18" },
  { title: "Morabeza", artist: "Carlos Rosa", plays: "76K", duration: "3:55" },
  { title: "Kriol Flow", artist: "MR.462", plays: "61K", duration: "2:58" },
  { title: "Mar di Saudade", artist: "Carlos Rosa", plays: "54K", duration: "4:34" },
];

export default function App() {
  const [currentlyPlaying, setCurrentlyPlaying] = useState<string | null>("carlos-rosa");
  const [showPlayer, setShowPlayer] = useState(true);
  const [activeTrack, setActiveTrack] = useState(0);

  const artists: Artist[] = [
    {
      id: "carlos-rosa",
      name: "Carlos Rosa",
      image: "https://images.unsplash.com/photo-1771894431319-7eb49cda5adb?w=600&h=600&fit=crop&auto=format",
      type: "audio",
      trackName: "Sodade de Nós Terra",
      genre: "MORNA",
      description: "Uma voz doce e melódica que preserva a alma de Cabo Verde através da morna tradicional, trazendo a nostalgia clássica para as novas gerações.",
      followers: "24.5K",
      tracks: [
        { title: "Sodade de Nós Terra", duration: "4:02", plays: "124K" },
        { title: "Morabeza", duration: "3:55", plays: "76K" },
        { title: "Mar di Saudade", duration: "4:34", plays: "54K" },
      ],
    },
    {
      id: "mr-462",
      name: "MR.462",
      image: "https://images.unsplash.com/photo-1762290965691-e74072600c03?w=600&h=600&fit=crop&auto=format",
      type: "audio",
      trackName: "Rua Di Mudança",
      genre: "DRILL",
      description: "Trazendo a energia urbana das ruas de Cabo Verde através do ritmo pulsante do Drill. Letras de intervenção social com flows marcantes.",
      followers: "18.2K",
      tracks: [
        { title: "Rua Di Mudança", duration: "3:18", plays: "98K" },
        { title: "Kriol Flow", duration: "2:58", plays: "61K" },
        { title: "No Sistema", duration: "3:44", plays: "39K" },
      ],
    },
  ];

  const events: Event[] = [
    {
      id: "1",
      title: "Festival de Música da Praia",
      date: "15 Jul 2026",
      location: "Santiago (Praia)",
      artists: "Carlos Rosa, MR.462",
      image: "https://images.unsplash.com/photo-1514525253161-7a46d19cd819?w=400&h=300&fit=crop&auto=format",
      price: "1.500 CVE",
      payment: "VINTI24 · VISA",
      available: 34,
    },
    {
      id: "2",
      title: "Noite de Morna Acústica",
      date: "22 Jul 2026",
      location: "São Vicente (Mindelo)",
      artists: "Carlos Rosa & Convidados",
      image: "https://images.unsplash.com/photo-1506157786151-b8491531f063?w=400&h=300&fit=crop&auto=format",
      price: "1.200 CVE",
      payment: "VINTI24 · VISA",
      available: 12,
    },
    {
      id: "3",
      title: "Drill Underground Fest",
      date: "5 Ago 2026",
      location: "Sal (Santa Maria)",
      artists: "MR.462 & Coletivo Crioulo",
      image: "https://images.unsplash.com/photo-1459749411175-04bf5292ceea?w=400&h=300&fit=crop&auto=format",
      price: "2.000 CVE",
      payment: "VINTI24 · VISA",
      available: 67,
    },
    {
      id: "4",
      title: "Eco-Concert Tarrafal",
      date: "12 Ago 2026",
      location: "Santiago (Tarrafal)",
      artists: "Vozes Independentes",
      image: "https://images.unsplash.com/photo-1514525253161-7a46d19cd819?w=400&h=300&fit=crop&auto=format",
      price: "800 CVE",
      payment: "VINTI24 · VISA",
      available: 0,
    },
  ];

  const handlePlayAudio = (artistId: string) => {
    if (currentlyPlaying === artistId) {
      setCurrentlyPlaying(null);
      setShowPlayer(false);
    } else {
      setCurrentlyPlaying(artistId);
      setShowPlayer(true);
    }
  };

  const currentArtist = artists.find((a) => a.id === currentlyPlaying);

  return (
    <div className="min-h-screen bg-[#080d18] text-[#f0f2f8]" style={{ scrollbarWidth: "none" }}>
      <style>{`
        ::-webkit-scrollbar { display: none; }
        * { scrollbar-width: none; }
      `}</style>

      <Header />
      <Hero />

      {/* Featured tracks — Spotify-style list */}
      <section className="py-16 bg-[#080d18]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between mb-8">
            <div className="flex items-center gap-3">
              <TrendingUp className="w-5 h-5 text-[#FF6B00]" />
              <h2 className="text-white font-bold text-2xl">Em Alta Esta Semana</h2>
            </div>
            <a href="#artistas" className="text-sm text-[#8892a4] hover:text-white transition-colors">Ver tudo</a>
          </div>

          <div className="bg-[#0f1729] rounded-2xl overflow-hidden border border-white/5">
            {/* Header row */}
            <div className="grid grid-cols-[auto,1fr,auto,auto] gap-4 px-6 py-3 border-b border-white/5">
              <span className="text-xs text-[#8892a4] w-5 text-center">#</span>
              <span className="text-xs text-[#8892a4]">Título</span>
              <span className="text-xs text-[#8892a4] hidden sm:block">Streams</span>
              <span className="text-xs text-[#8892a4]">Dur.</span>
            </div>
            {FEATURED_TRACKS.map((track, i) => (
              <div
                key={i}
                onClick={() => {
                  setActiveTrack(i);
                  const artist = artists.find((a) => a.name === track.artist);
                  if (artist) handlePlayAudio(artist.id);
                }}
                className={`grid grid-cols-[auto,1fr,auto,auto] gap-4 px-6 py-3.5 items-center cursor-pointer transition-colors group ${activeTrack === i ? "bg-white/5" : "hover:bg-white/5"}`}
              >
                <div className="w-5 text-center">
                  {activeTrack === i ? (
                    <div className="flex items-center justify-center gap-0.5">
                      {[0,1,2].map((b) => (
                        <div key={b} className="w-0.5 rounded-full" style={{ height: "12px", background: "linear-gradient(#FF6B00,#FFD700)", animation: `bounce 0.7s ${b*0.15}s infinite alternate ease-in-out` }} />
                      ))}
                    </div>
                  ) : (
                    <>
                      <span className="text-sm text-[#8892a4] group-hover:hidden">{i + 1}</span>
                      <Play className="w-3.5 h-3.5 text-white fill-white hidden group-hover:block mx-auto" />
                    </>
                  )}
                </div>
                <div>
                  <div className={`text-sm font-medium ${activeTrack === i ? "text-[#FFD700]" : "text-white"}`}>{track.title}</div>
                  <div className="text-xs text-[#8892a4]">{track.artist}</div>
                </div>
                <div className="text-xs text-[#8892a4] hidden sm:block">{track.plays}</div>
                <div className="text-xs text-[#8892a4]">{track.duration}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Artists */}
      <section id="artistas" className="py-16 bg-[#080d18]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center gap-3 mb-8">
            <Headphones className="w-5 h-5 text-[#FF6B00]" />
            <h2 className="text-white font-bold text-2xl">Artistas em Destaque</h2>
          </div>

          <div className="grid md:grid-cols-2 gap-6 max-w-5xl">
            {artists.map((artist) => (
              <ArtistCard
                key={artist.id}
                artist={artist}
                onPlayAudio={handlePlayAudio}
                isPlaying={currentlyPlaying === artist.id}
              />
            ))}
          </div>
        </div>
      </section>

      {/* Events */}
      <section id="eventos" className="py-16 bg-[#080d18]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between mb-8">
            <div className="flex items-center gap-3">
              <Ticket className="w-5 h-5 text-[#FF6B00]" />
              <h2 className="text-white font-bold text-2xl">Próximos Eventos</h2>
            </div>
            <button
              className="px-5 py-2 rounded-full text-sm font-semibold text-white border border-white/15 hover:bg-white/5 transition-colors"
            >
              Ver todos
            </button>
          </div>

          <div className="space-y-4">
            {events.map((event) => (
              <EventCard key={event.id} event={event} />
            ))}
          </div>
        </div>
      </section>

      {/* About — minimalist split */}
      <section id="sobre" className="py-20 bg-[#0a0f1e]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-3 gap-8">
            {[
              {
                icon: <Music2 className="w-6 h-6 text-[#FF6B00]" />,
                title: "A Gravadora",
                body: "A SCmusic nasce para tirar do anonimato os maiores talentos de Cabo Verde, transformando vozes promissoras em artistas de renome internacional.",
              },
              {
                icon: <Ticket className="w-6 h-6 text-[#FF6B00]" />,
                title: "Bilheteira Oficial",
                body: "Compre bilhetes 100% online para concertos e eventos. Pagamentos com Vinti4 e cartões internacionais — seguro e instantâneo.",
              },
              {
                icon: <Headphones className="w-6 h-6 text-[#FF6B00]" />,
                title: "Streaming Local",
                body: "Ouça os novos lançamentos diretamente no site. Divulgação dos ritmos tradicionais e modernos cabo-verdianos para o mundo.",
              },
            ].map((item) => (
              <div key={item.title} className="p-6 rounded-2xl bg-[#0f1729] border border-white/5 hover:border-white/10 transition-colors">
                <div className="w-11 h-11 rounded-xl flex items-center justify-center mb-4 border border-white/10" style={{ background: "rgba(255,107,0,0.1)" }}>
                  {item.icon}
                </div>
                <h3 className="text-white font-bold text-lg mb-2">{item.title}</h3>
                <p className="text-[#8892a4] text-sm leading-relaxed">{item.body}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <Footer />

      {/* Persistent bottom player — Spotify style */}
      {showPlayer && currentArtist && (
        <AudioPlayer
          artistName={currentArtist.name}
          trackName={currentArtist.trackName ?? ""}
          artistImage={currentArtist.image}
          onClose={() => { setShowPlayer(false); setCurrentlyPlaying(null); }}
        />
      )}

      <style>{`
        @keyframes bounce {
          from { transform: scaleY(0.4); }
          to { transform: scaleY(1); }
        }
      `}</style>

      {/* Bottom padding so content isn't hidden behind the player */}
      {showPlayer && <div className="h-24" />}
    </div>
  );
}
